<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  	<title>Trigger - Welcome</title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.min.css"> 
	<script type="text/javascript" charset="utf8" src="<?php echo base_url(); ?>assets/JS/validation.js"></script>
	<script src="http://cdn.ckeditor.com/4.7.0/basic/ckeditor.js"></script>
</head>
<body>

<div class="container">
