<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Mon ndd - connexion page</title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/base.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login.css">
	<script src="http://cdn.ckeditor.com/4.7.0/basic/ckeditor.js"></script>
</head>
<body>




				