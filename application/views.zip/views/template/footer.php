		</div>
		<script type="text/javascript"
		        src="<?php echo base_url(); ?>assets/JS/trigger.js"></script>
	</body> 
</html>